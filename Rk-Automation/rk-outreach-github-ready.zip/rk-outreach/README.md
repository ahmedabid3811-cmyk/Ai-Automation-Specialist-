# RK Outreach

Cold outreach sequencer for RK Group. Reads leads from a Google Sheet, validates
emails, and sends via SMTP.

## Local setup

```bash
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Add your own `service_account.json` (Google service account with Sheets API
access) and a `.env`-style export of `MAILBOX_1_PASSWORD` (the Gmail app
password) before running. Neither file is tracked by git (see `.gitignore`).

```bash
export MAILBOX_1_PASSWORD="your-gmail-app-password"
python rk_outreach.py check        # sanity-check config + credentials
python rk_outreach.py validate     # classify every row in the sheet
python rk_outreach.py preview      # see the rendered email
python rk_outreach.py test you@yourdomain.com --dry-run
```

## Running on GitHub Actions

The workflow at `.github/workflows/outreach.yml` runs the tool in the cloud
instead of your machine.

1. Push this repo to GitHub (see below).
2. In the repo, go to **Settings → Secrets and variables → Actions** and add:
   - `GOOGLE_SERVICE_ACCOUNT_JSON` — paste the full contents of your
     `service_account.json` file as one secret.
   - `MAILBOX_1_PASSWORD` — the Gmail app password.
3. Go to the **Actions** tab → **RK Outreach** → **Run workflow**, pick a
   command (`check`, `validate`, `rows`, `preview`), and run it.
4. Once you trust the setup, uncomment the `schedule:` block in the workflow
   file to run automatically (edit the cron time first).

**Never commit `service_account.json` or a real password/`.env` file** — the
GitHub secrets above replace them when running in Actions.

## Pushing this folder to GitHub

```bash
cd rk-outreach
git init
git add .
git commit -m "Initial commit: RK outreach tool"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

Create the empty repo on GitHub first (github.com → New repository) — don't
check "Initialize with README" if you're pushing existing history.
